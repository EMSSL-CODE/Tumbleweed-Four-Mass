% compare results

clc
close all
clear
SetDefaults

% load cone angle figure
s1 = load('Compare1A.mat');
x1 = s1.x;
t1 = s1.t;

% load kinematic figure
s2 = load('Compare1B.mat');
x2 = s2.x;
t2 = s2.t;

% plot angle
fig1 = figure;
hold on
plot(t1, x1(:, 1)*180/pi, 'DisplayName', sprintf('CA = %d deg', s1.ca));
plot(t2, x2(:, 1)*180/pi, 'DisplayName', 'Kinematics');
grid on
xlim([0, 120]);
ylabel('Angle [deg]');
xlabel('Time [s]');
legend('location', 'southeast');

% plot angle rate
fig2 = figure;
hold on
plot(t1, x1(:, 2)*180/pi, 'DisplayName', sprintf('CA = %d deg', s1.ca));
plot(t2, x2(:, 2)*180/pi, 'DisplayName', 'Kinematics');
grid on
xlim([0, 120]);
ylabel('Angular velocity [deg/s]');
xlabel('Time [s]');
legend('location', 'southeast');

% plot mass positions
fig3 = figure;
subplot(2, 2, 1)
hold on
title(sprintf('CA = %d deg', s1.ca))
plot(t1, x1(:, 3), 'DisplayName', '$r_1$');
plot(t1, x1(:, 5), 'DisplayName', '$r_3$');
grid on
xlim([0, 120]);
ylabel('Position [m]');
legend('location', 'southeast');

subplot(2, 2, 3)
hold on
plot(t1, x1(:, 4), 'DisplayName', '$r_2$');
plot(t1, x1(:, 6), 'DisplayName', '$r_4$');
grid on
xlim([0, 120]);
ylabel('Position [m]');
xlabel('Time [s]');
legend('location', 'southeast');

subplot(2, 2, 2)
hold on
title('Kinematics')
plot(t2, x2(:, 3), 'DisplayName', '$r_1$');
plot(t2, x2(:, 5), 'DisplayName', '$r_3$');
grid on
xlim([0, 120]);
legend('location', 'southeast');

subplot(2, 2, 4)
hold on
plot(t2, x2(:, 4), 'DisplayName', '$r_2$');
plot(t2, x2(:, 6), 'DisplayName', '$r_4$');
grid on
xlim([0, 120]);
xlabel('Time [s]');
legend('location', 'southeast');